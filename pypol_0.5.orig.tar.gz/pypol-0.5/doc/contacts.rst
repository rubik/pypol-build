Contacts
========

If you want to contact me for a bug, an enhancement or something else, you are in the right section.

Mail
++++

Mail-me at michelelacchia@gmail.com.

Project
+++++++

You can find the project on `github <http://github.com/rubik/pypol>`_.

Forums
++++++

You can also find me on various forums, like `Python-it.org forum <http://python-it.org/smfforum/index.php>`_ (username *Python*), `Python-forum.org <http://python-forum.org/pythonforum/index.php>`_ (username *rubik*) or the `Daniweb community <http://www.daniweb.com/forums/forum114.html>`_ (username *rubik-pypol*), and many other communities.
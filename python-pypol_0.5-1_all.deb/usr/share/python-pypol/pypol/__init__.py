from .core import *

x = monomial(x=1)
y = monomial(y=1)
z = monomial(z=1)
NULL = Polynomial()
ONE = monomial()
TWO = monomial(2)
THREE = monomial(3)